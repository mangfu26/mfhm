class TransmissionType(object):
    '''
    传输类型
    '''
    
    # 服务密钥类型, 表示服务开启了服务密钥验证
    authKey = 'key'

    # 服务密钥 + RSA加密类型, 表示服务在服务密钥的基础上开启了RSA加密
    authKeyRsa = 'key+rsa'