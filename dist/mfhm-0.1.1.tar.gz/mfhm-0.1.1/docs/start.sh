#!/bin/bash

mkdocs serve --dev-addr=0.0.0.0:10000