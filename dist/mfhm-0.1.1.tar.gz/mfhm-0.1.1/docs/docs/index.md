# MFHM - MangFu HTTP Microservices


<div align=center><img src="logo.png"></div>



## 简介

> 基于[HTTPX](https://github.com/encode/httpx)和[FastAPI](https://github.com/tiangolo/fastapi)的HTTP微服务框架，侧重于Web领域
>
> **注意：** 该项目只是本人用于研究微服务而创建的探索项目, 项目代码只注重功能的实现, 没有进行过严格的测试, 所以请将本项目用于个人/研究为目的/无关紧要的项目中, 切勿在生产项目中使用


## 菜鸟小声叭叭

该项目是工作之余自己捣鼓的，凭借个人对微服务的理解而开发，难免会有不足之处，大佬不喜勿喷(手动狗头保命)